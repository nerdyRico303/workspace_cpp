#include<iostream>
#include<fstream>
#include<conio.h>
#include<string>
#define FILENAME1 "student.txt"
#define FILENAME2 "account.txt"
using namespace std;